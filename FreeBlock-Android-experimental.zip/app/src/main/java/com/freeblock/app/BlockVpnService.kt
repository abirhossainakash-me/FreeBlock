package com.freeblock.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

class BlockVpnService : VpnService() {
    private var vpn: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val running = AtomicBoolean(false)
    private val blockedDomains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adform.net", "taboola.com",
        "outbrain.com", " scorecardresearch.com".trim(), "unityads.unity3d.com",
        "applovin.com", "app-measurement.com", "branch.io"
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpn == null) {
            vpn = Builder()
                .setSession("FreeBlock")
                .addAddress("10.10.10.1", 32)
                .addDnsServer("10.10.10.2")
                .addRoute("10.10.10.2", 32)
                .setMtu(1500)
                .establish()
            if (vpn == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            running.set(true)
            worker = Thread { runVpnLoop() }.apply { name = "FreeBlock-DNS"; start() }
        }
        return START_STICKY
    }

    private fun runVpnLoop() {
        val fd = vpn ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val packet = buffer.copyOf(length)
                handlePacket(packet, output)
            } catch (_: Exception) {
                if (running.get()) continue
            }
        }
    }

    private fun handlePacket(packet: ByteArray, output: FileOutputStream) {
        if (packet.size < 28) return
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return // IPv6 is not handled in this experimental version.
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (packet.size < ihl + 8 || (packet[9].toInt() and 0xFF) != 17) return
        val srcPort = u16(packet, ihl)
        val dstPort = u16(packet, ihl + 2)
        val udpLength = u16(packet, ihl + 4)
        if (dstPort != 53 || udpLength < 8 || ihl + udpLength > packet.size) return
        val dns = packet.copyOfRange(ihl + 8, ihl + udpLength)
        val domain = readQuestionName(dns) ?: return
        val blocked = blockedDomains.any { domain == it || domain.endsWith(".$it") }
        val answer = if (blocked) makeNxDomain(dns) else queryUpstream(dns) ?: return
        val response = makeIpv4UdpResponse(packet, ihl, srcPort, answer)
        output.write(response)
        output.flush()
    }

    private fun queryUpstream(dns: ByteArray): ByteArray? {
        var socket: DatagramSocket? = null
        return try {
            socket = DatagramSocket()
            if (!protect(socket)) return null
            socket.soTimeout = 2500
            val data = DatagramPacket(dns, dns.size, InetAddress.getByName("1.1.1.1"), 53)
            socket.send(data)
            val receive = ByteArray(4096)
            val reply = DatagramPacket(receive, receive.size)
            socket.receive(reply)
            receive.copyOf(reply.length)
        } catch (_: Exception) {
            null
        } finally {
            socket?.close()
        }
    }

    private fun readQuestionName(dns: ByteArray): String? {
        if (dns.size < 17) return null
        var p = 12
        val labels = mutableListOf<String>()
        while (p < dns.size) {
            val n = dns[p++].toInt() and 0xFF
            if (n == 0) break
            if (n > 63 || p + n > dns.size) return null
            labels.add(String(dns, p, n, Charsets.US_ASCII).lowercase())
            p += n
        }
        return if (labels.isEmpty()) null else labels.joinToString(".")
    }

    private fun makeNxDomain(query: ByteArray): ByteArray {
        val out = query.copyOf()
        if (out.size >= 4) {
            val flags = ((out[2].toInt() and 0xFF) shl 8) or (out[3].toInt() and 0xFF)
            val newFlags = (flags or 0x8000 or 0x0080 or 0x0003) and 0xFFF0.inv().or(0xFFFF)
            out[2] = (newFlags ushr 8).toByte()
            out[3] = newFlags.toByte()
            out[6] = 0; out[7] = 0
            out[8] = 0; out[9] = 0
            out[10] = 0; out[11] = 0
        }
        return out
    }

    private fun makeIpv4UdpResponse(original: ByteArray, ihl: Int, clientPort: Int, dns: ByteArray): ByteArray {
        val total = 20 + 8 + dns.size
        val out = ByteArray(total)
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, total)
        put16(out, 4, 0)
        put16(out, 6, 0x4000)
        out[8] = 64
        out[9] = 17
        // Source is the virtual DNS server; destination is the original client.
        out[12] = 10; out[13] = 10; out[14] = 10; out[15] = 2
        System.arraycopy(original, 12, out, 16, 4)
        put16(out, 10, checksum(out, 0, 20))
        put16(out, 20, 53)
        put16(out, 22, clientPort)
        put16(out, 24, 8 + dns.size)
        put16(out, 26, 0)
        System.arraycopy(dns, 0, out, 28, dns.size)
        return out
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or
                (if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0)
            sum += word
            i += 2
        }
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun u16(b: ByteArray, p: Int) =
        ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)

    private fun put16(b: ByteArray, p: Int, v: Int) {
        b[p] = (v ushr 8).toByte()
        b[p + 1] = v.toByte()
    }

    override fun onDestroy() {
        running.set(false)
        worker?.interrupt()
        vpn?.close()
        vpn = null
        super.onDestroy()
    }
}
