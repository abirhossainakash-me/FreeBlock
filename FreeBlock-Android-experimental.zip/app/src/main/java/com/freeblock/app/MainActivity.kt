package com.freeblock.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCode = 4101
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = TextView(this).apply { text = "FreeBlock"; textSize = 28f; setPadding(0, 24, 0, 8) }
        val info = TextView(this).apply {
            text = "Free Android DNS ad blocker (experimental). It may block many known ad/tracker domains, but cannot block every ad."
            textSize = 16f
        }
        val button = Button(this).apply { text = "Enable protection" }
        val stop = Button(this).apply { text = "Stop protection" }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(title); addView(info); addView(button); addView(stop)
        }
        setContentView(layout)
        button.setOnClickListener {
            val intent = VpnService.prepare(this)
            if (intent != null) startActivityForResult(intent, requestCode)
            else onActivityResult(requestCode, RESULT_OK, null)
        }
        stop.setOnClickListener { stopService(Intent(this, BlockVpnService::class.java)) }
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK) {
            startService(Intent(this, BlockVpnService::class.java))
        }
    }
}
