# FreeBlock Android — experimental DNS filter

This is an early experimental Android VPN/DNS-filter project, not a production-ready blocker.

## What it attempts
- Creates a local Android VPN interface and directs DNS requests to the local DNS handler.
- Checks a small built-in list of advertising/tracking domains.
- Returns NXDOMAIN for matching domains.
- For other IPv4/UDP DNS requests, forwards the DNS query to Cloudflare `1.1.1.1`.

## Important limitations
- This is not yet tested on a physical Android device.
- IPv6, TCP DNS, DNS-over-HTTPS (DoH), DNS-over-TLS (DoT), fragmented packets, and many edge cases are not handled.
- Only a small starter blocklist is included.
- It cannot reliably block YouTube/Facebook in-stream ads or guarantee all-app ad blocking.
- If the upstream DNS query fails, the app currently drops that query.
- Use at your own risk; stop the VPN if internet/DNS stops working.

## Build
The GitHub Actions workflow builds a debug APK on pushes to `main` or manual workflow dispatch.
